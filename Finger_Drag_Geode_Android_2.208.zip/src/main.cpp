#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/cocos/touch_dispatcher/CCTouchDelegateProtocol.h>
#include <Geode/cocos/touch_dispatcher/CCTouchDispatcher.h>
#include <Geode/cocos/base_nodes/CCNode.h>
#include <Geode/binding/GameObject.hpp>

using namespace geode::prelude;

namespace {
    GameObject* findObjectAt(CCNode* node, CCPoint worldPoint) {
        if (!node || !node->isVisible()) return nullptr;

        // Search children from front to back so the visually top object is selected first.
        auto children = node->getChildren();
        if (children) {
            for (int i = children->count() - 1; i >= 0; --i) {
                auto child = static_cast<CCNode*>(children->objectAtIndex(i));
                if (auto hit = findObjectAt(child, worldPoint))
                    return hit;
            }
        }

        auto obj = typeinfo_cast<GameObject*>(node);
        if (!obj) return nullptr;

        auto local = obj->convertToNodeSpace(worldPoint);
        auto rect = CCRect(0.f, 0.f, obj->getContentSize().width, obj->getContentSize().height);
        if (rect.containsPoint(local))
            return obj;

        return nullptr;
    }

    class DragTouchLayer : public CCLayer {
    protected:
        GameObject* m_dragged = nullptr;
        CCPoint m_offset = ccp(0.f, 0.f);

        bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
            auto playLayer = typeinfo_cast<PlayLayer*>(this->getParent());
            if (!playLayer) return false;

            auto p = touch->getLocation();
            auto obj = findObjectAt(playLayer, p);
            if (!obj) return false;

            m_dragged = obj;
            m_offset = obj->getPosition() - obj->getParent()->convertToNodeSpace(p);
            return true;
        }

        void ccTouchMoved(CCTouch* touch, CCEvent*) override {
            if (!m_dragged || !m_dragged->getParent()) return;

            auto parentPoint = m_dragged->getParent()->convertToNodeSpace(touch->getLocation());
            m_dragged->setPosition(parentPoint + m_offset);
        }

        void ccTouchEnded(CCTouch*, CCEvent*) override {
            m_dragged = nullptr;
        }

        void ccTouchCancelled(CCTouch*, CCEvent*) override {
            m_dragged = nullptr;
        }

        void registerWithTouchDispatcher() override {
            CCTouchDispatcher::get()->addTargetedDelegate(this, INT_MIN + 10, true);
        }

    public:
        static DragTouchLayer* create() {
            auto ret = new DragTouchLayer();
            if (ret && ret->init()) {
                ret->autorelease();
                return ret;
            }
            CC_SAFE_DELETE(ret);
            return nullptr;
        }

        bool init() {
            if (!CCLayer::init()) return false;
            this->setTouchEnabled(true);
            return true;
        }
    };
}

class $modify(FingerDragPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects))
            return false;

        auto layer = DragTouchLayer::create();
        if (!layer) return true;

        layer->setContentSize(this->getContentSize());
        layer->setPosition(CCPointZero);
        this->addChild(layer, 999999);

        log::info("Finger Drag: touch-drag layer enabled");
        return true;
    }
};
