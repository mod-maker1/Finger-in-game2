# Finger Drag

Android Geode 5.10.1 / Geometry Dash 2.208 prototype.

Touch a visible GameObject in a level, hold, and move your finger. The selected object is moved with the finger.

This is intentionally a prototype: it does not yet filter by Group ID.
