Finger Drag — source project

Target:
- Geode 5.10.1
- Geometry Dash Android 2.208

Important:
This environment does not contain the Android NDK/Geode Android SDK binaries, so a final .geode Android binary cannot be compiled here.

To build:
1. Install the Geode SDK and Android NDK.
2. Install Android binaries:
   geode sdk install-binaries -p android64
3. Build:
   geode build -p android64
4. Copy the resulting .geode from build-android64 to:
   /storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/

The current prototype grabs the GameObject directly under the finger and moves it. It does not use Mouse or Keyboard.
